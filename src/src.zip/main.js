// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import iView from 'iview'
import axios from 'axios'
import util from './util/util'
import 'iview/dist/styles/iview.css'
import './theme/index.less'
import echarts from 'echarts'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'


import i18n from './i18n'
import ViewUI from 'view-design'
import 'font-awesome/css/font-awesome.min.css'

// Vue.use(util);
Vue.use(ElementUI)
// axios.defaults.withCredentials = true
Vue.prototype.util = util
Vue.prototype.$echarts = echarts
Vue.config.productionTip = false
Vue.use(iView)
Vue.prototype.$ajax = axios.create({
    withCredentials: true,
    crossDomain: true
})
axios.defaults.withCredentials = true


/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    template: '<App/>',
    components: {App}
})
